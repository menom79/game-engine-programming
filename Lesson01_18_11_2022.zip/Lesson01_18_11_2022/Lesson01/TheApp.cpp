#include "TheApp.h"


TheApp::TheApp()
{
}

TheApp::~TheApp()
{
}

bool TheApp::OnCreate()
{
	// load resources
	auto renderer = GetOpenGLRenderer();
	m_uVertexShader = renderer->CreateVertexShaderFromFile("vertexshader.vs");
	m_uFragmentShader = renderer->CreateFragmentShaderFromFile("fragmentshader.fs");
	m_uProgram = renderer->CreateProgram(m_uVertexShader, m_uFragmentShader);
	m_uTexture = renderer->CreateTexture("toyo.jpeg");
	if (!m_uVertexShader || !m_uFragmentShader || !m_uProgram || !m_uTexture)
	{
		return false;
	}

	const glm::mat4 view = glm::lookAt(glm::vec3(0.0f, 0.0f, 5.0f),
		glm::vec3(0.0f, 0.0f, 0.0f),
		glm::vec3(0.0f, 1.0f, 0.0f));
	renderer->SetViewMatrix(view);

	const glm::mat4 projection = glm::perspective(0.61f, GetAspect(), 1.0f, 500.0f);
	renderer->SetProjectionMatrix(projection);

	// generate geometry
	constexpr float radius = 1.0f;
	m_pTorus = std::make_shared<Geometry>();
	m_pTorus->GenTorus(32, radius, radius * 0.5f);

	// set the material
	m_pMaterial = std::make_shared<Material>();

	// build scenegraph
	m_pSceneRoot = std::make_unique<Node>();

	for (size_t i = 0; i < 25; ++i)
	{
		auto node = std::make_shared<GeometryNode>(m_pTorus, m_pMaterial);
		node->SetPos(glm::vec3(glm::linearRand(-5.0f, 5.0f),
			glm::linearRand(-5.0f, 5.0f),
			glm::linearRand(-20.0f, 0.0f)));
		node->SetRotationSpeed(glm::linearRand(-5.0f, 5.0f));

		/*
		node->SetVelocity(glm::vec3(glm::linearRand(-10.0f, 10.0f),
			glm::linearRand(-10.0f, 10.0f),
			glm::linearRand(-10.0f, 0.0f)));
			*/

		node->SetRadius(radius);

		m_pSceneRoot->AddNode(node);
	}

	return true;
}

void TheApp::OnDestroy()
{
	m_pSceneRoot = nullptr;

	glDeleteTextures(1, &m_uTexture);
	glDeleteProgram(m_uProgram);
	glDeleteShader(m_uFragmentShader);
	glDeleteShader(m_uVertexShader);

	m_uTexture = 0;
	m_uVertexShader = 0;
	m_uFragmentShader = 0;
	m_uProgram = 0;
}

void TheApp::OnUpdate(float fFrametime)
{
	if (m_pSceneRoot)
	{
		m_pSceneRoot->Update(fFrametime);
	}
}


void TheApp::OnDraw(IRenderer& renderer)
{
	renderer.Clear(0.1f, 0.1f, 0.1f, 1.0f);

	glUseProgram(m_uProgram);

	// set the texture
	glActiveTexture(GL_TEXTURE0);
	glBindTexture(GL_TEXTURE_2D, m_uTexture);
	GLint loc = glGetUniformLocation(m_uProgram, "texture01");
	glUniform1i(loc, 0);

	// set light position
	glm::vec3 lightPos(0.0f, 0.0f, 15.0f);
	loc = glGetUniformLocation(m_uProgram, "lightPosition");
	glUniform3f(loc, lightPos.x, lightPos.y, lightPos.z);

	// set cam position
	glm::vec3 campos(-renderer.GetViewMatrix()[3]);
	loc = glGetUniformLocation(m_uProgram, "cameraPosition");
	glUniform3f(loc, campos.x, campos.y, campos.z);

	// set alpha blending
	glEnable(GL_BLEND);
	glBlendFunc(GL_ONE, GL_ONE_MINUS_SRC_ALPHA);

	if (m_pSceneRoot)
	{
		m_pSceneRoot->Render(renderer, m_uProgram);
	}
}


void TheApp::OnScreenSizeChanged(uint32_t widthPixels, uint32_t heightPixels)
{
	const glm::mat4 projection = glm::perspective(0.61f, GetAspect(), 1.0f, 500.0f);
	GetRenderer()->SetProjectionMatrix(projection);
}


bool TheApp::OnKeyDown(uint32_t uKeyCode)
{
	if (uKeyCode == VK_ESCAPE)
	{
		Close();
		return true;
	}
	return false;
}

