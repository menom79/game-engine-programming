
#include "TheApp.h"

int APIENTRY WinMain(HINSTANCE hInst, HINSTANCE hPrevInstance, LPSTR pCmdLine, int nCmdShow)
{
	TheApp app;
	app.Create(1280, 720, "Super Game Engine!");
	app.Run();

	return 0;
}

